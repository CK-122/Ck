import { config } from 'dotenv';
config();

import '@/ai/flows/generate-marksheet.ts';
import '@/ai/flows/generate-admit-cards.ts';
